# author: Alex Miracle
# IDE: Visual Studio Code
# Date: 10/13/2024

# This program is designed to help users manage their finances by tracking income and expenses. 
# It provies a user-friendly interface to add, view, and delete transactions, export the data
# to an Excel file, and view a summary of the current finanical status. Data is saved in a JSON 
# file so that users can resume tracking where they left off. The program also offers an 'About
# section for user guidance. 

# External libraries used: 
#   - tkinter: for creating the GUI
#   - pandas: for exporting data to an Excel file
#   - PIL (Pillow): for handling and displaying images


import tkinter as tk
from tkinter import ttk
import os
import json
import pandas as pd
from PIL import Image, ImageTk

# setting up main application window
class BudgetTrackerApp:
    def __init__ (self,root):
        self.root = root
        self.root.title("Expense Echo")

        # initialize income and expense trackers
        self.total_income = 0
        self.total_expenses = 0

        # attributes to track individual income and expense entries
        self.incomes =[]
        self.expenses = []

        # handle window close event
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        # load any saved data
        self.load_data()

        # create initial home screen
        self.create_home_screen()
    
    # loads data from a JSON file if it exists
    def load_data(self):
        if os.path.exists("budget_data.json"):
            with open("budget_data.json", "r") as file:
                data = json.load(file)
                self.total_income = data.get("total_income", 0)
                self.total_expenses = data.get("total_expenses", 0)
                self.incomes = data.get("incomes", [])
                self.expenses = data.get("expenses", [])

    # saves the current data to a JSON file
    def save_data(self):
        data = {
            "total_income": self.total_income,
            "total_expenses": self.total_expenses,
            "incomes": self.incomes,
            "expenses": self.expenses
        }
        with open ("budget_data.json", "w") as file:
            json.dump(data, file)
        print("Data saved to budget_data.json")

    # function called when the user closes the window
    def on_closing(self):
        self.save_data()
        self.root.destroy()

    


    # create the home screen interface with a summary of income/expenses
    def create_home_screen(self):
        self.clear_screen()
        self.root.configure(bg='#e0f7fa')

        font_style = ('Helvetica', 12)

        # image for home screen
        self.image_path = 'dollarimage.png'  
        self.image = Image.open(self.image_path)
        self.image = self.image.resize((75, 75), Image.LANCZOS)
        self.tk_image = ImageTk.PhotoImage(self.image)

        # alt text for the image
        self.image_alt_text = "A dollar sign icon representing financial tracking."

        # create a label to display the image
        image_label = tk.Label(self.root, image=self.tk_image, bg='#e0f7fa')
        image_label.pack(pady=(10, 0))  

      

        # display summary of income, expense, and remaining balance
        tk.Label(self.root, text="Welcome to Expense Echo!", font=("Helvetica", 16, "bold"), bg='#e0f7fa').pack(pady=10)
        tk.Label(self.root, text=f"Total Income: ${self.total_income:.2f}", font=font_style, bg='#e0f7fa').pack(pady=2)
        tk.Label(self.root, text=f"Total Expenses: ${self.total_expenses:.2f}", font=font_style, bg='#e0f7fa').pack(pady=2)
        tk.Label(self.root, text=f"Remaining Balance: ${self.total_income - self.total_expenses:.2f}", font=font_style, bg='#e0f7fa').pack(pady=10)
        
        # create buttons for different sections
        button_style = {'bg': '#00796b', 'fg': 'white', 'font': font_style, 'padx': 10, 'pady': 5}
        tk.Button(self.root, text="Add Income", command=self.create_add_income_screen, **button_style).pack(pady=5)
        tk.Button(self.root, text="Add Expense", command=self.create_add_expense_screen, **button_style).pack(pady=5)
        tk.Button(self.root, text="Export to Excel", command=self.export_to_excel, **button_style).pack(pady=5)
        tk.Button(self.root, text="View History", command=self.create_transaction_history_screen, **button_style).pack(pady=5)
        tk.Button(self.root, text="About", command=self.create_about_window, **button_style).pack(pady=5)

    # the second window requirement/ create about window
    def create_about_window(self):
        about_window = tk.Toplevel(self.root)  
        about_window.title("About Expense Echo")
        about_window.geometry("800x500")
        about_window.configure(bg='#e0f7fa')

        # load and display the expense echo image
        self.about_image_path = "expenseecho.png"  
        self.about_image = Image.open(self.about_image_path)
        self.about_image = self.about_image.resize((250, 150), Image.LANCZOS)  
        self.about_photo = ImageTk.PhotoImage(self.about_image)

        # alt text for the about image
        self.about_image_alt_text = "Logo of Expense Echo"

        # add the image label to the About window
        image_label = tk.Label(about_window, image=self.about_photo, bg='#e0f7fa')
        image_label.pack(pady=10)

        # add welcome message
        tk.Label(about_window, text="Welcome to Expense Echo!", font=("Helvetica", 16, "bold"), bg='#e0f7fa').pack(pady=10)
        
        # instructions on how to use the app
        instructions = (
            "This application is designed to help you manage your finances effectively.\n\n"
            "Here’s how to use it:\n"
            "1. Add Income: Enter your income amount and description to keep track of your earnings.\n"
            "2. Add Expense: Record your expenses by inputting the amount and category to monitor your spending.\n"
            "3. View History: View a list of all your recorded incomes and expenses for better financial insights.You can also delete any entries here. \n"
            "4. Export to Excel: Export your transaction data to an Excel file for a detailed view of your finances and easier record-keeping.\n\n"
            "Feel free to explore the features and take control of your budget!"
        )

        # display the instructions text
        tk.Label(about_window, text=instructions, font=("Helvetica", 10), bg='#e0f7fa', justify="left").pack(pady=10)

        # close button to exit the about window
        tk.Button(about_window, text="Close", command=about_window.destroy, bg='#d32f2f', fg='white').pack(pady=5)

    # create transaction history screen
    def create_transaction_history_screen(self):
        self.clear_screen()

        # display title
        tk.Label(self.root, text="Transaction History", font=("Helvetica", 16, "bold"), bg='#e0f7fa').pack(pady=10)

        # create a frame that will contain the canvas and the scrollbar
        frame = tk.Frame(self.root, bg='#e0f7fa')
        frame.pack(fill='both', expand=True)


        # create a canvas and a scrollbar
        canvas = tk.Canvas(frame, bg='#e0f7fa')
        scrollbar = tk.Scrollbar(frame, orient="vertical", command=canvas.yview)

        # create a frame that will contain the transaction entries
        self.transaction_frame = tk.Frame(canvas, bg='#e0f7fa')
        

        # create a window in the canvas to contain the frame
        self.transaction_window = canvas.create_window((0, 0), window=self.transaction_frame, anchor='nw')

        # configure the canvas
        canvas.configure(yscrollcommand=scrollbar.set)

        # pack the scrollbar and canvas
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        # bind the configure event to update the scroll region
        self.transaction_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self.root.bind_all("<MouseWheel>", lambda event, canvas=canvas: self._on_mouse_wheel(event, canvas))

        # back button
        tk.Button(self.transaction_frame, text="Back", command=self.create_home_screen, bg='#00796b', fg='white').pack(pady=5)


        # display income entries
        income_label = tk.Label(self.transaction_frame, text="Income Entries", font=("Helvetica", 14, "bold"), bg='#e0f7fa')
        income_label.pack(pady=(10, 5))

        # check if there are any income entries, if not display a message
        if not self.incomes:
            tk.Label(self.transaction_frame, text="No income entries found.", bg='#e0f7fa').pack(pady=5)
        else:
            # loop through income entries and display each one with a delete button
            for index, income in enumerate(self.incomes):
                entry_frame = tk.Frame(self.transaction_frame, bg='#e0f7fa', padx=10, pady=5)
                entry_frame.pack(fill='x', padx=10, pady=2)

                entry_label = tk.Label(entry_frame, text=f"${income['amount']:.2f} - {income['category']} ({income['description']})", bg='#e0f7fa')
                entry_label.pack(side='left')

                delete_button = tk.Button(entry_frame, text="Delete", command=lambda i=index: self.delete_income(i), bg='#d32f2f', fg='white')
                delete_button.pack(side='right')
        # display expense entries
        expense_label = tk.Label(self.transaction_frame, text="Expense Entries", font=("Helvetica", 14, "bold"), bg='#e0f7fa')
        expense_label.pack(pady=(10, 5))

        # check if there are any expense entries, if not display a message
        if not self.expenses:
            tk.Label(self.transaction_frame, text="No expense entries found.", bg='#e0f7fa').pack(pady=5)
        else:
            # loop through expense entries and display each one with a delete button
            for index, expense in enumerate(self.expenses):
                entry_frame = tk.Frame(self.transaction_frame, bg='#e0f7fa', padx=10, pady=5)
                entry_frame.pack(fill='x', padx=10, pady=2)

                entry_label = tk.Label(entry_frame, text=f"${expense['amount']:.2f} - {expense['category']} ({expense['description']})", bg='#e0f7fa')
                entry_label.pack(side='left')

                delete_button = tk.Button(entry_frame, text="Delete", command=lambda i=index: self.delete_expense(i), bg='#d32f2f', fg='white')
                delete_button.pack(side='right')
        
        # update the canvas and frame background color
        self.transaction_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

    # use mouse wheel to scroll
    def _on_mouse_wheel(self, event, canvas):
        canvas.yview_scroll(int(-1*(event.delta/120)), "units")

   
    # screen to add income details
    def create_add_income_screen(self):
        self.clear_screen()
        self.root.configure(bg='#e0f7fa')

        tk.Label(self.root, text="Add Income", font=("Helvetica", 16, "bold"), bg='#e0f7fa').pack(pady=10)

        # frame for input fields
        input_frame = tk.Frame(self.root, bg='#e0f7fa')
        input_frame.pack(pady=10, padx=20)

        # error label for input validation
        self.error_label = tk.Label(input_frame, text="", fg="red", bg='#e0f7fa')
        self.error_label.grid(row=0, columnspan=2)

        # amount field
        tk.Label(input_frame, text="Amount:", bg='#e0f7fa').grid(row=1, column=0, sticky='w', pady=5)
        self.income_amount_entry = tk.Entry(input_frame)
        self.income_amount_entry.grid(row=1, column=1, pady=5)

        # category dropdown
        tk.Label(input_frame, text="Category:", bg='#e0f7fa').grid(row=2, column=0, sticky='w', pady=5)
        category_options = ["Salary", "Business", "Investment", "Other"]
        self.category_dropdown = ttk.Combobox(input_frame, values=category_options)
        self.category_dropdown.grid(row=2, column=1, pady=5)

        # description field
        tk.Label(input_frame, text="Description:", bg='#e0f7fa').grid(row=3, column=0, sticky='w', pady=5)
        self.description_entry = tk.Entry(input_frame)
        self.description_entry.grid(row=3, column=1, pady=5)

        # save and cancel buttons
        button_frame = tk.Frame(self.root, bg='#e0f7fa')
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Save", command=self.save_income, bg='#00796b', fg='white').grid(row=0, column=0, padx=5)
        tk.Button(button_frame, text="Cancel", command=self.create_home_screen, bg='#d32f2f', fg='white').grid(row=0, column=1, padx=5)

    # save income details and update the home screen
    def save_income(self):
        amount = self.income_amount_entry.get()
        try:
            amount = float(amount)
            self.total_income += amount  
        except ValueError:
            self.display_error("Invalid amount, please enter a number.")
            return

        self.error_label.config(text="")

        category = self.category_dropdown.get()
        description = self.description_entry.get()

        self.incomes.append({
            "amount": amount,
            "category": category,
            "description": description
        })

        # update the home screen with new total income
        self.create_home_screen()

    

   # screen to add expense details
    def create_add_expense_screen(self):
        self.clear_screen()
        self.root.configure(bg='#e0f7fa')

        tk.Label(self.root, text="Add Expense", font=("Helvetica", 16, "bold"), bg='#e0f7fa').pack(pady=10)

        # frame for input fields
        input_frame = tk.Frame(self.root, bg='#e0f7fa')
        input_frame.pack(pady=10, padx=20)

        # error label for input validation
        self.error_label = tk.Label(input_frame, text="", fg="red", bg='#e0f7fa')
        self.error_label.grid(row=0, columnspan=2)

        # amount field
        tk.Label(input_frame, text="Amount:", bg='#e0f7fa').grid(row=1, column=0, sticky='w', pady=5)
        self.expense_amount_entry = tk.Entry(input_frame)
        self.expense_amount_entry.grid(row=1, column=1, pady=5)

        # category dropdown
        tk.Label(input_frame, text="Category:", bg='#e0f7fa').grid(row=2, column=0, sticky='w', pady=5)
        category_options = ["Food", "Transportation", "Rent", "Utilities", "Other"]
        self.category_dropdown = ttk.Combobox(input_frame, values=category_options)
        self.category_dropdown.grid(row=2, column=1, pady=5)

        # description field
        tk.Label(input_frame, text="Description:", bg='#e0f7fa').grid(row=3, column=0, sticky='w', pady=5)
        self.description_entry = tk.Entry(input_frame)
        self.description_entry.grid(row=3, column=1, pady=5)

        # save and cancel buttons
        button_frame = tk.Frame(self.root, bg='#e0f7fa')
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Save", command=self.save_expense, bg='#00796b', fg='white').grid(row=0, column=0, padx=5)
        tk.Button(button_frame, text="Cancel", command=self.create_home_screen, bg='#d32f2f', fg='white').grid(row=0, column=1, padx=5)

    # save expense details and update the home screen
    def save_expense(self):
        amount = self.expense_amount_entry.get()
        try:
            amount = float(amount)
            self.total_expenses += amount  
        except ValueError:
            self.display_error("Invalid amount, please enter a number.")
            return

        self.error_label.config(text="")

        category = self.category_dropdown.get()
        description = self.description_entry.get()

        self.expenses.append({
            "amount": amount,
            "category": category,
            "description": description
        })

        # update the home screen with new total expenses
        self.create_home_screen()


    # display error messages
    def display_error(self, message):
        self.error_label.config(text=message)

    
   
    # export the budget data to an Excel file
    def export_to_excel(self):
        income_data = {
            "Type": ["Income"] * len(self.incomes),
            "Amount": [entry['amount'] for entry in self.incomes],
            "Category": [entry['category'] for entry in self.incomes],
            "Description": [entry['description'] for entry in self.incomes]
        }

        expense_data = {
            "Type": ["Expense"] * len(self.expenses),
            "Amount": [entry['amount'] for entry in self.expenses],
            "Category": [entry['category'] for entry in self.expenses],
            "Description": [entry['description'] for entry in self.expenses]
        }

        # combine both income and expense data into a single DataFrame
        df_income = pd.DataFrame(income_data)
        df_expense = pd.DataFrame(expense_data)

        df_transactions = pd.concat([df_income, df_expense], ignore_index=True)

        # add a totals row at the bottom
        totals_data = {
            "Type": ["Total"],
            "Amount": [self.total_income],
            "Category": ["N/A"],
            "Description": ["N/A"]
        }

        df_totals = pd.DataFrame(totals_data)

        # create a remaining balance row
        balance_data = {
            "Type": ["Remaining Balance"],
            "Amount": [self.total_income - self.total_expenses],
            "Category": ["N/A"],
            "Description": ["N/A"]
        }

        df_balance = pd.DataFrame(balance_data)

        # append totals and balance rows to the transactions DataFrame
        df_final = pd.concat([df_transactions, df_totals, df_balance], ignore_index=True)

        # ensure no MultiIndex is used
        df_final.columns = df_final.columns.tolist()  

        # export to Excel
        file_name = 'budget_report.xlsx'
        df_final.to_excel(file_name, index=False)
        print("Data exported to budget_report.xlsx")

    # clear the current screen
    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    # delete income entry by index
    def delete_income(self, index):
        del self.incomes[index]
        self.total_income = sum(entry['amount'] for entry in self.incomes)
        self.create_transaction_history_screen()

    # delete expense entry by index
    def delete_expense(self, index):
        del self.expenses[index]
        self.total_expenses = sum(entry['amount'] for entry in self.expenses)
        self.create_transaction_history_screen()

# initialize main Tkinter window and start the budget tracker app
if __name__ == "__main__":
    root = tk.Tk()
    app = BudgetTrackerApp(root)
    root.mainloop()
